import pygame
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
switches = [18, 17, 12, 16, 13]
GPIO.setup(switches, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
pygame.init()
win = pygame.display.set_mode((500, 500))
pygame.display.set_caption("Tech Detective")
guessbox = 1
selectbox1 = 0
selectbox2 = 0
x = 50
y = 50
width = 40
height = 60
vel = 5
run = True
class Frame():
    def __init__(self, img):
        self.img = pygame.image.load(img)
        self.object = ["whaddup"]
        self.exit = []
    @property
    def object(self):
        return self._object
    @object.setter
    def object(self, value):
        self._object = value

    def addObject(self, x, y, description, img):
        npc = pygame.Rect(x, y, 60, 40)
        self.object[0] = description
        newImage = pygame.image.load(img)
        win.blit(newImage, (x, y))
        return npc
    def addExit(self, x, y, img):
        pygame.Rect(x, y, 40, 60)
        newImage = pygame.image.load(img)
        win.blit(newImage, (x, y))
        
        return pygame.Rect(x, y, 40, 60)
    def addTextBox(self):
        textBox = pygame.draw.rect(win, (255, 255, 255), (0, 427, 497, 70),2)
        pygame.Surface.fill(win, [0,0,0], rect = textBox)
        return textBox
def text_objects(text, font):
    textSurface = font.render(text, True, (0,0,255))
    return textSurface, textSurface.get_rect()
def get_rect(thing):
    return pygame.Rect(thing.x, thing.y, thing.width, thing.height)

text = pygame.font.SysFont("comicsansms", 25)
f1 = Frame('police.jpg')
f2 = Frame('quad.jpg')
f3 = Frame('center.jpg')
f4 = Frame('mist.jpg')
f5 = Frame('tolliver.jpg')
f6 = Frame('bookstore.jpg')
f0 = Frame("Guess2.png")
fwin = Frame("Game_Win.jpg")
flose = Frame("Game_Lose.jpg")
player = pygame.image.load('One.png')
currentFrame = f1
while(run):
    pygame.time.delay(10)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    if currentFrame == fwin or currentFrame == flose:
        win.blit(currentFrame.img, (0,0))
        pygame.display.update()
    else:
        if GPIO.input(17) == False and x > vel:
            x -= vel
        if GPIO.input(13) == False and x < 500 - width - vel:
            x += vel
        if GPIO.input(12) == False and y < 427 - height - vel:
            y += vel
        if GPIO.input(18) == False and y > vel:
            y-= vel
        currentbox = pygame.Rect(x, y, width, height)  
        win.blit(currentFrame.img, (0,0))
        words = "Try and Find the Killer"
        if currentFrame == f1:
            exitbox = f1.addExit(250, 0, 'Up.png')
            npc = f1.addObject(300, 300, "Hello Detective, I heard gunfire north.", 'Four.png')
            if(currentbox.colliderect(exitbox)):
                currentFrame = f2
            if(currentbox.colliderect(npc)):
                words = f1.object[0]
        if currentFrame == f2:
            exitbox = f2.addExit(350, 250, 'Right.png')
            npc = f2.addObject(400, 350,"Please give me an A", 'Two.png')
            if(currentbox.colliderect(exitbox)):
                currentFrame = f4
            if(currentbox.colliderect(npc)):
                words = f2.object[0]

        if currentFrame == f3:
            exitbox = f3.addExit(220,350, 'Down.png')
            npc = f3.addObject(100,250, "I really need this, I am so poor", 'Three.png')
            if(currentbox.colliderect(exitbox)):
                currentFrame = f5
            if(currentbox.colliderect(npc)):
                words = f3.object[0]

        if currentFrame == f4:
            exitbox = f4.addExit(210,100, 'Left.png')
            npc = f4.addObject(100, 103, "Psst hey, Suzy is the murderer", 'Five.png')
            if(currentbox.colliderect(exitbox)):
                currentFrame = f3
            if(currentbox.colliderect(npc)):
                words = f4.object[0]

        if currentFrame == f5:
            exitbox = f5.addExit(300,150, 'Down.png')
            npc = f5.addObject(50, 115, "I think Brian looks suspicious", 'Four.png')
            if(currentbox.colliderect(exitbox)):
                currentFrame = f6
            if(currentbox.colliderect(npc)):
                words = f5.object[0]

        if currentFrame == f6:
            exitbox = f6.addExit(150,50, 'Cop.png')
            exitbox1 = f6.addExit(300, 300, 'Left.png')
            npc = f6.addObject(83, 75, "Wait a minute, this isn't China!", 'walk3.png')
            if(currentbox.colliderect(exitbox)):
                currentFrame = f0
            if(currentbox.colliderect(exitbox1)):
                currentFrame = f1
            if(currentbox.colliderect(npc)):
                words = f6.object[0]

        if currentFrame == f0:
            pygame.time.delay(100)
            keys = pygame.key.get_pressed()
            if GPIO.input(12) == False and guessbox != 7:
                guessbox += 1
            if GPIO.input(18) == False and guessbox != 1:
                guessbox -= 1
            if GPIO.input(16) and guessbox <4:
                selectbox1 = guessbox
            if GPIO.input(16) and guessbox >4:
                selectbox2 = guessbox
            if guessbox == 1:
                pygame.draw.rect(win, (255, 255, 255), (0, 100, 130, 40),2)
            if guessbox == 2:
                pygame.draw.rect(win, (255, 255, 255), (0, 200, 130, 40),2)
            if guessbox == 3:
                pygame.draw.rect(win, (255, 255, 255), (0, 300, 130, 40),2)
            if guessbox == 4:
                pygame.draw.rect(win, (255, 255, 255), (180, 450, 130, 40),2)
                if GPIO.input(16)and selectbox1 > 0 and selectbox2 >0:
                    if selectbox1 == 2 and selectbox2 == 5:
                        currentFrame = fwin
                    else:
                        currentFrame = flose

            if guessbox == 5:
                pygame.draw.rect(win, (255, 255, 255), (370, 100, 130, 40),2)
            if guessbox == 6:
                pygame.draw.rect(win, (255, 255, 255), (370, 200, 130, 40),2)
            if guessbox == 7:
                pygame.draw.rect(win, (255, 255, 255), (370, 300, 130, 40),2)
                
            if selectbox1 == 1:
                pygame.draw.rect(win, (255, 0, 0), (0, 100, 130, 40),2)
            if selectbox1 == 2:
                pygame.draw.rect(win, (255, 0, 0), (0, 200, 130, 40),2)
            if selectbox1 == 3:
                pygame.draw.rect(win, (255, 0, 0), (0, 300, 130, 40),2)
            if selectbox2 == 5:
                pygame.draw.rect(win, (0, 255, 0), (370, 100, 130, 40),2)
            if selectbox2 == 6:
                pygame.draw.rect(win, (0, 255, 0), (370, 200, 130, 40),2)
            if selectbox2 == 7:
                pygame.draw.rect(win, (0, 255, 0), (370, 300, 130, 40),2)


        else:
            textBox = currentFrame.addTextBox()
            textSurf, textRect = text_objects(words, text)
            win.blit(player, (x,y))
            textRect.center = ((497/2), (427 + 35))
            win.blit(textSurf, textRect)
        
    pygame.display.update()

pygame.quit()
